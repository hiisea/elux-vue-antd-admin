module.exports = {
  presets: [['@elux', {ui: 'vue'}]],
};
