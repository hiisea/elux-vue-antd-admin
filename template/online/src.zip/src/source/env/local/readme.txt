- 默认本地环境设置，可不上传Git，本目录中的内容可以覆盖项目中的：
  /public
  /elux.config.js
